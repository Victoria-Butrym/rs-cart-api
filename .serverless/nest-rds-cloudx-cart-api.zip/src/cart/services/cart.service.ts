import { Injectable } from '@nestjs/common';
import { Carts } from 'src/database/entities/carts.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DataSource } from 'typeorm';

import { v4 } from 'uuid';

import { Cart } from '../models';
import { CartInfo } from 'src/database/entities/cart-info.entity';

@Injectable()
export class CartService {
  private userCarts: Record<string, Cart> = {};

  constructor(
    @InjectRepository(Carts)
        private cartRepository: Repository<Carts>,
        private dataSource: DataSource
  ) {}

  async findAllCarts() {
    return this.cartRepository.find();
  }

  async findCartById(id: string) {
    return this.cartRepository.findOne({
      where: { id },
      // relations: { cart_info: true }
  });
  }

  async create(body: any) {
    const { user_id, created_at, updated_at, count, status } = body;
    let cart;
    try {
        await this.dataSource.transaction(async manager => {
            cart = await manager.save(Carts, {
                user_id,
                created_at,
                updated_at,
                status,
            })
        })
        return cart;
    } catch (e) {
        return 'cart creation failed!';
    }
  }

  async deleteCart(id: string) {
    return this.cartRepository.delete({ id })
  }

  findByUserId(userId: string): Cart {
    return this.userCarts[ userId ];
  }

  createByUserId(userId: string) {
    const id = v4(v4());
    const userCart = {
      id,
      items: [],
    };

    this.userCarts[ userId ] = userCart;

    return userCart;
  }

  findOrCreateByUserId(userId: string): Cart {
    const userCart = this.findByUserId(userId);

    if (userCart) {
      return userCart;
    }

    return this.createByUserId(userId);
  }

  updateByUserId(userId: string, { items }: Cart): Cart {
    const { id, ...rest } = this.findOrCreateByUserId(userId);

    const updatedCart = {
      id,
      ...rest,
      items: [ ...items ],
    }

    this.userCarts[ userId ] = { ...updatedCart };

    return { ...updatedCart };
  }

  removeByUserId(userId): void {
    this.userCarts[ userId ] = null;
  }

}

